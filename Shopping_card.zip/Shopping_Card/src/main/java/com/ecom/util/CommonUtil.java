package com.ecom.util;

public class CommonUtil {
	
	public static Boolean sendMail()
	{
		return false;
	}

}
