package com.ecom.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecom.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{

    // All active products
    List<Product> findByIsActiveTrue();

    // Active products by category
    List<Product> findByCategoryAndIsActiveTrue(String category);

    // Latest active products (sorted by id descending)
    List<Product> findByIsActiveTrueOrderByIdDesc();

	List<Product> findByCategory(String category);

}




