package com.ecom.service;

public interface OrderService {

}
