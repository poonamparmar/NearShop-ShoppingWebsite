package com.ecom.service;

import java.util.List;

import com.ecom.model.UserDtls;

public interface UserService {

	public UserDtls saveUser(UserDtls user);
	
	public UserDtls getUserByEmail(String email);
	
	public List<UserDtls> getUsers();

	public Boolean updateAccountStatus(Integer id, Boolean status);

	List<UserDtls> getUsers(String role);
	
	public void increaseFailedAttemt(UserDtls user);
	
	public void userAccountLock(UserDtls user);
	
	public boolean unlockAccountTimeExired(UserDtls user);
	
	public void resetAttempt(int userId);
}
